from ase.io import read,write,iread

for structind,struct in enumerate(iread('current_population.traj')):
    write('ga_s_%04d.cif' % structind,struct)
