import sys
import os
import glob
import subprocess

# Example: python copyJSON.py qe July_11/Ni
#  qe: which directory (Ni or Cr, etc.)
#  July_11/Ni: Where to copy the files into
#  > The correct lattice files will be made, just give the base directory for the element

def writeTo(prefix):
    #match prefix:
    print(prefix)
    if "bcc" in prefix: 
        return "bcc"
    elif "diamond" in prefix:
        return "diamond" 
    elif "ct_" in prefix:
        return "ct"
    elif "so_" in prefix:
        return "so"
    elif "boco" in prefix:
        return "boco"
    elif "bcm" in prefix:
        return "bcm"
    elif "hcp" in prefix:
        return "hcp"
    elif "fco" in prefix:
        return "fco"
    elif "_sm_" in prefix:
        return "sm"
    elif "_h_" in prefix:
        return "h"
    elif "sc_" in prefix:
        return "sc"
    elif "fcc" in prefix:
        return "fcc"
    elif "st_" in prefix:
        return "st"
    elif "baco" in prefix:
        return "baco"
    elif "_t_" in prefix:
        return "t"

def copyEosJSON(location):
    struct_files = glob.glob('*eos_*.cif')
    for fileindex,sfile in enumerate(struct_files):
        dirname = 'eos_%03d' % fileindex
        os.chdir(dirname)
        to = "../../../JSON/%s/%s_eos" % (toPaste, location)
        toRun = "cp *.json %s" % to
        print(dirname, toRun)
        subprocess.run(toRun, shell=True) # comment out to do a dry run
        os.chdir('../')
 

def copyRlxJSON(prefix):
    location = writeTo(prefix)
    to = "../../JSON/%s/%s_rlx" % (toPaste, location)
    toRun = "cp *.json %s" % to
    print(toRun)
    subprocess.run(toRun, shell=True) # comment out to do a dry run
    print("copying eos files in", dirname)
    copyEosJSON(location)

fromDirname = sys.argv[1]
toPaste = sys.argv[2]

toCopy = '../../../%s' % fromDirname

os.chdir(toCopy)

struct_files = glob.glob('*.cif')
for fileindex,sfile in enumerate(struct_files):
    prefix = sfile.split('.')[0]
    dirname = 'run_%03d' % fileindex
    os.chdir(dirname)
    print("copying JSON files from", dirname, "to", toPaste)
    copyRlxJSON(prefix)
    os.chdir('../')

